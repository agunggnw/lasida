# Deadline 29 March 2017

- Dashboard : Done
- Pelanggan
  - CRUD : Done
- Tagihan & Pembayaran
  - Tampil Data : Done
  - AutoComplete Find no pelanggan : Onproggress
- Laporan
  - Tagihan
    - Tampil Data : Udah gua update sqlnya masih belum jalan
    - Cetak Data : DONE
  - Pelanggan
    - Tampil Data : DONE
    - Cetak Data : DONE
- Administrator
  - CRUD : BUG
      - Pass Edit Password, Meskipun data tidak sama masih bisa masuk - (Fixed, Test)
      - Hapus Staff, notifikasinya berhasil hapus adminstrator - (Fixed, Test)
- Master & Konfigurasi
  - Kecamatan 
    - CRUD : DONE
  - Kelurahan
    - CRUD : DONE
  - Konfigurasi
    - Ubah harga permeter : DONE
    - Tambah Pelanggan : Field Kelurahan Belum ada - (Test)
    - Tambah Tagihan : Belum Bisa [ Ada Error ] - (Test)
  
