<?php
$tagihan = $_GET['filter_tagihan'];
header("location:tagihan.php?bayar=$tagihan");

 ?>