<?php
include 'ganti_harga.php';
include 'tambah_pelanggan.php';
include 'tambah_tagihan.php';
?>